<?php
class ModDashboardHelper
{
     
    public static function getSites()
    {
      return 'Hello!';
    }
}